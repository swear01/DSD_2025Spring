# HOW TO RUN

Should run the vcs Command right in the directory of the file, so that the testbench can find the test data.  